package com.example.ai_chat_assistant.ui.viewmodels

import android.app.Application
import androidx.lifecycle.*
import com.example.ai_chat_assistant.data.*
import com.example.ai_chat_assistant.network.OpenAiClient
import kotlinx.coroutines.launch

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = ChatDatabase.get(app).messageDao()
    val messages: LiveData<List<Message>> = dao.getAll().asLiveData()

    fun send(text: String) = viewModelScope.launch {
        val userMsg = Message(text = text, isUser = true)
        dao.insert(userMsg)

        val reply = try { OpenAiClient.ask(text) } catch (e: Exception) {
            "⚠️ Error: ${e.localizedMessage}"
        }
        dao.insert(Message(text = reply, isUser = false))
    }

    fun clearHistory() = viewModelScope.launch { dao.clear() }
}