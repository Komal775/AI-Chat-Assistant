package com.example.ai_chat_assistant.data

import android.content.Context
import androidx.room.*

@Database(entities = [Message::class], version = 1, exportSchema = false)
abstract class ChatDatabase : RoomDatabase() {
    abstract fun messageDao(): MessageDao

    companion object {
        @Volatile private var INSTANCE: ChatDatabase? = null
        fun get(context: Context) = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context, ChatDatabase::class.java, "chat.db"
            ).build().also { INSTANCE = it }
        }
    }
}