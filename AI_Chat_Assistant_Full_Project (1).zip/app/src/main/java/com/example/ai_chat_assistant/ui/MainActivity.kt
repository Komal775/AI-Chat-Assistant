package com.example.ai_chat_assistant.ui

import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.Gravity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.ai_chat_assistant.databinding.ActivityMainBinding
import com.example.ai_chat_assistant.ui.viewmodels.ChatViewModel
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var vb: ActivityMainBinding
    private val vm: ChatViewModel by viewModels()
    private val adapter = ChatAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        vb = ActivityMainBinding.inflate(layoutInflater)
        setContentView(vb.root)

        vb.recycler.apply {
            layoutManager = LinearLayoutManager(this@MainActivity).apply {
                stackFromEnd = true
            }
            adapter = this@MainActivity.adapter
        }

        vm.messages.observe(this) {
            adapter.submitList(it) {
                vb.recycler.scrollToPosition(adapter.itemCount - 1)
            }
        }

        vb.sendBtn.setOnClickListener { sendInput() }
        vb.micBtn.setOnClickListener { startSpeechToText() }
    }

    private fun sendInput() {
        val text = vb.inputEdit.text.toString().trim()
        if (text.isNotEmpty()) {
            vm.send(text)
            vb.inputEdit.text?.clear()
        }
    }

    private val sttIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
    }

    private val sttLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { res ->
        if (res.resultCode == RESULT_OK) {
            val spoken = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrEmpty()) vb.inputEdit.setText(spoken)
        }
    }

    private fun startSpeechToText() = sttLauncher.launch(sttIntent)
}