package com.example.ai_chat_assistant.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages ORDER BY timestamp ASC")
    fun getAll(): Flow<List<Message>>

    @Insert suspend fun insert(message: Message)
    @Query("DELETE FROM messages") suspend fun clear()
}