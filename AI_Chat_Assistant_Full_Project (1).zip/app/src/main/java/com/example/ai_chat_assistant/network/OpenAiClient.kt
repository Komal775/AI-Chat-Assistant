package com.example.ai_chat_assistant.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*

interface OpenAiApi {
    @POST("chat/completions")
    suspend fun chat(@Body body: ChatBody): ChatResponse
}

data class ChatBody(
    val model: String = "gpt-3.5-turbo",
    val messages: List<Map<String, String>>,
    val temperature: Double = 0.7
)

data class ChatResponse(val choices: List<Choice>) {
    data class Choice(val message: MessageObj)
    data class MessageObj(val role: String, val content: String)
}

object OpenAiClient {
    private const val BASE_URL = "https://api.openai.com/v1/"
    private const val API_KEY = "sk-REPLACE_WITH_YOUR_KEY"

    private val api by lazy {
        val ok = OkHttpClient.Builder()
            .addInterceptor { chain ->
                chain.proceed(
                    chain.request().newBuilder()
                        .addHeader("Authorization", "Bearer $API_KEY")
                        .build()
                )
            }
            .addInterceptor(HttpLoggingInterceptor().apply {
                setLevel(HttpLoggingInterceptor.Level.BASIC)
            })
            .build()

        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .client(ok)
            .build()
            .create(OpenAiApi::class.java)
    }

    suspend fun ask(prompt: String): String = withContext(Dispatchers.IO) {
        val body = ChatBody(messages = listOf(mapOf("role" to "user", "content" to prompt)))
        val res = api.chat(body)
        res.choices.first().message.content.trim()
    }
}