# 🤖 AI-Powered Chat Assistant App

A smart conversational Android app built using OpenAI GPT API that allows users to chat using text or voice. It also stores chat history using Room Database for a seamless user experience.

## 🚀 Features

- 💬 Chat with AI using GPT (gpt-3.5-turbo)
- 🎙️ Voice Input via Speech-to-Text (Android's built-in recognizer)
- 🗂️ Chat History stored locally using Room DB
- 🧾 RecyclerView UI for chat bubble display
- 🔄 Automatically reloads previous chats on app launch

## 🧰 Tech Stack

| Component        | Technology                 |
|------------------|-----------------------------|
| Language         | Kotlin                      |
| Architecture     | MVVM                        |
| AI Integration   | OpenAI GPT API              |
| UI               | RecyclerView + Material 3   |
| Voice Input      | Android SpeechRecognizer    |
| Database         | Room (SQLite)               |
| API Layer        | Retrofit + Gson             |
| Lifecycle        | ViewModel + LiveData        |

## 🛠️ Setup Instructions

1. Clone this repository
2. Open in Android Studio
3. Add your OpenAI API key in `OpenAiClient.kt`
4. Run on Emulator or Real Device

## 📄 License

This project is licensed under the MIT License.
Built as part of the Application Development Internship with Codec Technologies.
